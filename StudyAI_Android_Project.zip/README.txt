STUDYAI ANDROID PROJECT

This is a starter Android project for StudyAI.

BUILD:
1. Open the project in an Android-compatible IDE/cloud builder.
2. Let Gradle sync/download dependencies.
3. Build the debug APK.
4. Install the APK on your Redmi Pad.

IMPORTANT:
This starter UI is demo mode. To make it a real AI app, connect the Ask action to a secure backend.
Do NOT put an OpenAI API key inside the Android app or APK.
