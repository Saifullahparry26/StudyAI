package com.studyai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ChatMessage(val text: String, val user: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyAIApp() }
    }
}

@Composable
fun StudyAIApp() {
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(
        ChatMessage("Hi! I'm StudyAI. Ask me a study question.", false)
    ) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("StudyAI 🤖") }) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { input = "Explain Newton's laws simply." }) {
                        Text("Physics")
                    }
                    Button(onClick = { input = "Explain photosynthesis simply." }) {
                        Text("Biology")
                    }
                }

                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { msg ->
                        Text(
                            text = if (msg.user) "You: ${msg.text}" else "StudyAI: ${msg.text}",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask a question...") }
                    )
                    Button(onClick = {
                        if (input.isNotBlank()) {
                            messages.add(ChatMessage(input, true))
                            messages.add(
                                ChatMessage(
                                    "Demo mode. Connect this app to your secure AI backend to receive real AI answers.",
                                    false
                                )
                            )
                            input = ""
                        }
                    }) {
                        Text("Ask")
                    }
                }
            }
        }
    }
}
